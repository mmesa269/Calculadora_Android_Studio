package com.example.testes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class Mainlistview {

    private Button btn_transfer_ltm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_transfer_ltm = findViewById(R.id.transfer_ltm);
        btn_transfer_ltm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        public static void irAlImageView(View view) {
            Intent intent = new Intent(packageContext:this,ImageViewActivity.class);

        }

    }
}
