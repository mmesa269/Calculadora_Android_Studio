package com.example.testes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText tnum1, tnum2;
    private Button btn_calcular;
    private TextView tresultado;
    private RadioButton rbsuma, rbresta, rbmultiplicar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tnum1 = findViewById(R.id.num1);
        tnum2 = findViewById(R.id.num2);
        tresultado = findViewById(R.id.resultado);
        btn_calcular = findViewById(R.id.calcular);

        rbmultiplicar = findViewById(R.id.multiplicar);
        rbsuma = findViewById(R.id.suma);
        rbresta = findViewById(R.id.resta);
    }

    public void clickCalcular (View view){
        String valor1_string = tnum1.getText().toString();
        String valor2_string = tnum2.getText().toString();

        if(valor1_string.equals("")){
            tnum1.setError("El campo es obligatorio");
            return;
        } else if (valor2_string.equals("")) {
            tnum2.setError("El campo es obligatorio");
            return;
        }

        Double valor1_double = Double.parseDouble(valor1_string);
        Double valor2_double = Double.parseDouble(valor2_string);

        Double resultado = 0.0;

        if (rbsuma.isChecked()){
            resultado = valor1_double + valor2_double;
        } else if (rbresta.isChecked()){
            resultado = valor1_double - valor2_double;
        } else if (rbmultiplicar.isChecked()){
            resultado = valor1_double * valor2_double;
        }


        Double finalResultado = resultado;
        btn_calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tresultado.setText(String.valueOf(finalResultado)+"");
            }
        });
    }
}

